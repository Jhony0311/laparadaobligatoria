<!-- Hero image -->
<section class="hero">
    <div class="hero__image" style="background-image: url('<?php the_field('hero_image'); ?>')"></div>
    <div class="hero__opacity"></div>
    <div class="hero__tt">
        <h1 class="hero__title"><?php the_title(); ?></h1>
        <h1 class="hero__subtitle"><?php the_field('hero_tagline'); ?></h1>
    </div>
</section>
