<time class="updated" datetime="<?= get_post_time('c', true); ?>"><?= get_the_date('l, F j, Y'); ?></time>
